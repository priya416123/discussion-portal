import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs';
import { BooksService } from '../services/books.service';
import { debounceTime } from 'rxjs/operators';


@Component({
  selector: 'app-stitch-btn',
  templateUrl: './stitch-btn.component.html',
  styleUrls: ['./stitch-btn.component.css']
})
export class StitchBtnComponent implements OnInit,OnDestroy {
  stitchForm: FormGroup;
  books;
  chapters;
  results;
  subscriptions:Subscription[] = [];
  toggleButton:boolean = false;
  constructor(private fb: FormBuilder,private bookService:BooksService) { }

  ngOnInit() {
    let subs = this.bookService.getBooks().subscribe((res:any)=>{
      this.books = res;
    });
    this.subscriptions.push(subs);
    this.stitchForm = this.fb.group({
      book_title: new FormControl('', Validators.required),
      chapter_name: new FormControl(''),
    });

    let sub1 = this.stitchForm.get('book_title').valueChanges
    .pipe(
      debounceTime(200)
    )
    .subscribe(result => {
      this.results = this.books.filter(d => 
        result.toLowerCase() != d.bookName && result.length > 0 && d.bookName.toLowerCase().includes(result.toLowerCase())
      )
    })
    this.subscriptions.push(sub1);
  }

  onStitchButtonClick(){
    this.toggleButton = !this.toggleButton;
  }

  onSubmit(e:any){
    console.log(e.value)
  }

  onBookSelect(e:any){
    this.stitchForm.patchValue({
      book_title: e.bookName
    });
    this.chapters = e.chapters;
    setTimeout(() => {
      this.results = [];
    }, 500);

  }

  onChapterSelect(e:any){
    this.stitchForm.patchValue({
      chapter_name: e.chapterName
    });
    setTimeout(() => {
      this.chapters = [];
    }, 500);
  }

  ngOnDestroy(){
    this.subscriptions.forEach((sub:Subscription)=>{
      sub.unsubscribe()
    })
  }

}
