import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

/*
Features:
Create a book
Create a Chapter
Create a Note
Browse all books
*/

export class AppComponent {
  title = 'stitch-book';

}
