import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector, APP_INITIALIZER } from '@angular/core';
import { RouterModule } from '@angular/router'
import { AppComponent } from './app.component';
import { HeaderComponent } from './layout/header/header.component';
import { BookListComponent } from './books/book-list/book-list.component';
import { StitchBtnComponent } from './stitch-btn/stitch-btn.component';
import { createCustomElement } from '@angular/elements';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './layout/home/home.component';
import { BookViewComponent } from './books/book-view/book-view.component';
import { KeycloakService, KeycloakAngularModule } from 'keycloak-angular';
import { environment } from 'src/environments/environment';

export function loginInitializer(keycloak: KeycloakService): () => Promise<any> {
  return (): Promise<any> => {
    return new Promise(async (resolve, reject) => {
      try {
        await keycloak.init({
          config: environment.keycloakConfig,
          initOptions: {
            onLoad: 'login-required',
            checkLoginIframe: false
          },
          enableBearerInterceptor: true,
        });
        resolve();
      } catch (error) {
        console.log("Error thrown in init "+error);
        reject(error);
      }
    });
  };            
}

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    BookListComponent,
    StitchBtnComponent,
    HomeComponent,
    BookViewComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    KeycloakAngularModule,
    RouterModule.forRoot([
      { path:  '', component:  HomeComponent},
      { path:  'view/:id', component:  BookViewComponent},
    ]
    )
  ],
  providers: [
    { provide: APP_INITIALIZER, useFactory: loginInitializer, multi: true, deps: [KeycloakService] }
  ],
  bootstrap: [AppComponent],
  //bootstrap:[],
  entryComponents:[
    StitchBtnComponent,
  ]
})
export class AppModule {
  constructor(private injector: Injector) {
  }
  ngDoBootstrap() {
    const myCustomElement = createCustomElement(StitchBtnComponent, { injector: this.injector });
    customElements.define('app-stitch-btn', myCustomElement);
  }
 }
