import { Component, OnInit } from '@angular/core';
import { BooksService } from 'src/app/services/books.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  books;
  subscriptions = [];
  constructor(private bookService:BooksService){}
  ngOnInit(){
    let sub = this.bookService.getBooks().subscribe((res:any)=>{
      this.books = res;
    })

    this.subscriptions.push(sub);
  }

  ngOnDestroy(){
    this.subscriptions.forEach((sub:Subscription)=>{
      sub.unsubscribe()
    })
  }
}
