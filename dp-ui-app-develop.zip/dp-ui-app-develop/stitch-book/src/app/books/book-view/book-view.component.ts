import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BooksService } from '../../services/books.service';
import { Subscription } from 'rxjs';
import { KeycloakService } from 'keycloak-angular';

@Component({
  selector: 'app-book-view',
  templateUrl: './book-view.component.html',
  styleUrls: ['./book-view.component.css']
})
export class BookViewComponent implements OnInit,OnDestroy {
  book;
  userName;
  subscriptions:Subscription[];
  constructor(private route: ActivatedRoute, private bookService:BooksService,
    private keycloakService:KeycloakService) { }

  ngOnInit() {
    this.userName = this.keycloakService.getUsername();
    this.subscriptions = [];
    let sub = this.route.paramMap.subscribe(params => {
      let bookId = params.get('id');
      let subs = this.bookService.getBookById(bookId).subscribe((book:any) => {
        console.log(book);
       this.book = book ;
       console.log(this.book)
      })
      this.subscriptions.push(subs);
      });

      this.subscriptions.push(sub);
  }

  ngOnDestroy(){
    this.subscriptions.forEach((sub:Subscription)=>{
      sub.unsubscribe()
    })
  }

}
