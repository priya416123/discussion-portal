const _ = require('lodash');
const { TOPICS, RESPONSES } = require('./entities');

const httpErrors = require('http-errors');
const shortid = require('shortid');
const contentType = 'application/json; charset=utf-8';

exports.createResponse = async (req, reply) => {
  try {
    const topic = req.db
      .get(TOPICS)
      .find({ topicId: req.params.topicId })
      .value();

    if (topic === undefined) {
      reply.send(httpErrors.NotFound);
      return;
    }

    const response = { responseId: shortid.generate(), ...req.body };
    topic[RESPONSES].push(response);

    reply.code(201).header('Content-Type', contentType).send(topic);
  } catch (err) {
    req.log.error(err);
    reply.send(httpErrors.InternalServerError());
  }
};
