const _ = require('lodash');
const { TOPICS, RESPONSES } = require('./entities');

const httpErrors = require('http-errors');
const shortid = require('shortid');
const contentType = 'application/json; charset=utf-8';

exports.createTopic = async (req, reply) => {
  try {
    const topic = { topicId: shortid.generate(), ...req.body, [RESPONSES]: [] };
    req.db.get(TOPICS).push(topic).value();

    reply.code(201).header('Content-Type', contentType).send(topic);
  } catch (err) {
    req.log.error(err);
    reply.send(httpErrors.InternalServerError());
  }
};

exports.getAllTopics = async (req, reply) => {
  try {
    const topics = req.db
      .get(TOPICS)
      .map((record) =>
        _.pick(record, ['topicId', 'category', 'topic', 'question'])
      )
      .value();

    reply.code(200).header('Content-Type', contentType).send(topics);
  } catch (err) {
    req.log.error(err);
    reply.send(httpErrors.InternalServerError());
  }
};

exports.getTopicById = async (req, reply) => {
  try {
    const topic = req.db
      .get(TOPICS)
      .find({ topicId: req.params.topicId })
      .value();
    if (topic === undefined) {
      reply.send(httpErrors.NotFound);
      return;
    }
    reply.code(200).header('Content-Type', contentType).send(topic);
  } catch (err) {
    req.log.error(err);
    reply.send(httpErrors.InternalServerError());
  }
};
