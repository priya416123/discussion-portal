const topics = require('./topics-handlers');
const responses = require('./responses-handlers');

const topicsRoutes = [
  { method: 'POST', url: '/api/topics', handler: topics.createTopic },
  { method: 'GET', url: '/api/topics', handler: topics.getAllTopics },
  { method: 'GET', url: '/api/topics/:topicId', handler: topics.getTopicById },
];

const responsesRoutes = [
  {
    method: 'POST',
    url: '/api/topics/:topicId/responses',
    handler: responses.createResponse,
  },
];

const routes = [...topicsRoutes, ...responsesRoutes];

module.exports = routes;
