const TOPICS = 'topics';
const RESPONSES = 'responses';

module.exports = {
  TOPICS,
  RESPONSES,
};
