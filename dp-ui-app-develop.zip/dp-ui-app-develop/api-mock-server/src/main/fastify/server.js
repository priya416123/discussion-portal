// Require the framework and instantiate it
const fastify = require('fastify')({ logger: true });
const path = require('path');

const dbPath = path.join(__dirname, 'db.json');
const lowDb = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');

const routes = require('./routes.js');

fastify.register(require('fastify-cors'), { 
  origin: '*',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH']
})

routes.forEach((route) => {
  fastify.route(route);
});

const adapter = new FileSync(dbPath);
const db = lowDb(adapter);

fastify.decorateRequest('db', db);

// Run the server!
const start = async () => {
  try {
    await fastify.listen(3000);
    fastify.log.info(`server listening on ${fastify.server.address().port}`);
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

start();

// Clean Exit

const signals = ['SIGINT', 'SIGTERM'];

signals.forEach((signal) => {
  process.on(signal, () => {
    console.log(`Process ${process.pid} received a ${signal} signal`);
    
    // Uncomment db.write(), in case you want to persist the test data
    // db.write();

    setTimeout(() => {
      process.exit(0);
    }, 1000).unref();
  });
});
