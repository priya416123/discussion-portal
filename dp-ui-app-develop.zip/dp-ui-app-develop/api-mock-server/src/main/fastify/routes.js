const topics = require('./discussion-portal-mocks/topics');
const books = require('./stitch-book-mocks/books');

const routes = [...topics, ...books];

module.exports = routes;
