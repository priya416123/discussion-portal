const _ = require('lodash');
const { BOOKS, CHAPTERS, NOTES } = require('./entities');
const { findBookById, findChapterById } = require('./entities');

const httpErrors = require('http-errors');
const shortid = require('shortid');
const contentType = 'application/json; charset=utf-8';

exports.createNote = async (req, reply) => {
  try {
    const chapter = findChapterById(
      req.db,
      req.params.bookId,
      req.params.chapterId
    );
    if (chapter === undefined) {
      reply.send(httpErrors.NotFound());
      return;
    }

    reqNotes = req.body;
    reqNotes.forEach((note) => {
      chapter[NOTES].push({ noteId: shortid.generate(), ...note });
    });

    reply.code(201).header('Content-Type', contentType).send(chapter[NOTES]);
  } catch (err) {
    req.log.error(err);
    reply.send(httpErrors.InternalServerError());
  }
};
