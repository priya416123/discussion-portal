const _ = require('lodash');
const { BOOKS, CHAPTERS, NOTES } = require('./entities');
const { findBookById, findChapterById } = require('./entities');

const httpErrors = require('http-errors');
const shortid = require('shortid');
const contentType = 'application/json; charset=utf-8';

exports.createChapter = async (req, reply) => {
  try {
    const book = findBookById(req.db, req.params.bookId);
    if (book === undefined) {
      reply.send(httpErrors.NotFound);
      return;
    }

    const chapter = { chapterId: shortid.generate(), ...req.body, [NOTES]: [] };
    book[CHAPTERS].push(chapter);

    reply.code(201).header('Content-Type', contentType).send(chapter);
  } catch (err) {
    req.log.error(err);
    reply.send(httpErrors.InternalServerError());
  }
};
