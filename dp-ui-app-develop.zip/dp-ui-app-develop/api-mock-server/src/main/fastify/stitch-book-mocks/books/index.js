const books = require('./books-handlers');
const chapters = require('./chapters-handlers');
const notes = require('./notes-handlers');

const booksRoutes = [
  { method: 'POST', url: '/api/books', handler: books.createBook },
  { method: 'GET', url: '/api/books', handler: books.getAllBooks },
  { method: 'GET', url: '/api/books/:bookId', handler: books.getBookById },
];

const chaptersRoutes = [
  {
    method: 'POST',
    url: '/api/books/:bookId/chapters',
    handler: chapters.createChapter,
  },
];

const notesRoutes = [
  {
    method: 'POST',
    url: '/api/books/:bookId/chapters/:chapterId/notes',
    handler: notes.createNote,
  },
];

const routes = [...booksRoutes, ...chaptersRoutes, ...notesRoutes];

module.exports = routes;
