const _ = require('lodash');

const BOOKS = 'books';
const CHAPTERS = 'chapters';
const NOTES = 'notes';

const findBookById = (db, bookId) => {
  return db.get(BOOKS).find({ bookId: bookId }).value();
};

const findChapterById = (db, bookId, chapterId) => {
  const book = findBookById(db, bookId);
  if (book === undefined) return;

  const chapter = _.find(book[CHAPTERS], {
    chapterId: chapterId,
  });
  return chapter;
};

module.exports = {
  BOOKS,
  CHAPTERS,
  NOTES,
  findBookById,
  findChapterById,
};
