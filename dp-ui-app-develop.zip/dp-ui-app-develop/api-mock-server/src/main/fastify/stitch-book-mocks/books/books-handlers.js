const _ = require('lodash');
const { BOOKS, CHAPTERS, findBookById } = require('./entities');

const httpErrors = require('http-errors');
const shortid = require('shortid');
const contentType = 'application/json; charset=utf-8';

exports.createBook = async (req, reply) => {
  try {
    const book = { bookId: shortid.generate(), ...req.body };
    req.db.get(BOOKS).push(book).value();

    reply.code(201).header('Content-Type', contentType).send(book);
  } catch (err) {
    req.log.error(err);
    reply.send(httpErrors.InternalServerError());
  }
};

exports.getAllBooks = async (req, reply) => {
  try {
    const books = req.db
      .get(BOOKS)
      .map((record) => _.pick(record, ['bookId', 'bookName', 'description','chapters']))
      .value();
    reply.code(200).header('Content-Type', contentType).send(books);
  } catch (err) {
    req.log.error(err);
    reply.send(httpErrors.InternalServerError());
  }
};

exports.getBookById = async (req, reply) => {
  try {
    const book = findBookById(req.db, req.params.bookId);
    if (book === undefined) {
      reply.send(httpErrors.NotFound);
      return;
    }
    reply.code(200).header('Content-Type', contentType).send(book);
  } catch (err) {
    req.log.error(err);
    reply.send(httpErrors.InternalServerError());
  }
};
