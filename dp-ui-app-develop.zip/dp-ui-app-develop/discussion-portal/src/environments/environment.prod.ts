
import { KeycloakConfig } from 'keycloak-angular';

export const environment = {
  production: true
};

let keycloakConfig: KeycloakConfig = {
  url: 'http://localhost:8080/auth/',
  // url: 'http://localhost:8080/auth',
  realm: 'my-enterprise',
  clientId: 'me-client'
};
