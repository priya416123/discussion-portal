import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PostQuestionComponent } from './components/post-question/post-question.component';
import { HomeComponent } from './components/home/home.component';
import { PostDetailsComponent } from './components/post-details/post-details.component';



const routes: Routes = [
  {
    path: "",
    component: HomeComponent
  },
  {
    path: "question",
    component: PostQuestionComponent
  },
  {
    path: "details/:id",
    component: PostDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
