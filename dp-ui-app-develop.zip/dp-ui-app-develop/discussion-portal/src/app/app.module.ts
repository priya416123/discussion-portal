import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './shared/material/material.module';
import { HeaderComponent } from './layout/header/header.component';
import { PostQuestionComponent } from './components/post-question/post-question.component';
import { EditorModule } from '@tinymce/tinymce-angular';
import { HomeComponent } from './components/home/home.component';
import { PostDetailsComponent } from './components/post-details/post-details.component';
import { LoaderComponent } from './shared/loader/loader.component';
import { ReplyComponent } from './components/reply/reply.component';
import { FilterPipe } from './components/filterpipe';
import { StitchBtnComponent } from './components/stitch-btn/stitch-btn.component';
import { KeycloakService, KeycloakAngularModule } from 'keycloak-angular';
import { environment } from 'src/environments/environment';


export function loginInitializer(keycloak: KeycloakService): () => Promise<any> {
  return (): Promise<any> => {
    return new Promise(async (resolve, reject) => {
      try {
        await keycloak.init({
          config: environment.keycloakConfig,
          initOptions: {
            onLoad: 'login-required',
            checkLoginIframe: false
          },
          enableBearerInterceptor: true,
        });
        resolve();
      } catch (error) {
        console.log("Error thrown in init "+error);
        reject(error);
      }
    });
  };            
}


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    PostQuestionComponent,
    HomeComponent,
    PostDetailsComponent,
    LoaderComponent,
    ReplyComponent,
    FilterPipe,
    StitchBtnComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    EditorModule,
    KeycloakAngularModule,
  

  ],
  entryComponents:[ReplyComponent],
  providers:[
    { provide: APP_INITIALIZER, useFactory: loginInitializer, multi: true, deps: [KeycloakService] }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
