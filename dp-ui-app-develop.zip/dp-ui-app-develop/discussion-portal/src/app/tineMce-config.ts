export const CONFIG: any ={
  init: {
    plugins:["advlist autolink lists link image charmap print preview hr anchor pagebreak",
    "searchreplace wordcount visualblocks visualchars code fullscreen",
    "insertdatetime media nonbreaking save table contextmenu directionality",
    "emoticons template paste textcolor colorpicker textpattern image imagetools tiny_mce_wiris"],
    default_link_target: '_blank',
    toolbar: 'formatselect | bold italic strikethrough | link image table lists | alignleft aligncenter alignright alignjustify | numlist bullist outdent indent | removeformat | code preview | tiny_mce_wiris_formulaEditor',
    height: 250,
    external_plugins: { tiny_mce_wiris: 'https://www.wiris.net/demo/plugins/tiny_mce/plugin.js' },
    placeholder:"Enter Question",
    theme: 'modern',
    branding: false,
    table_responsive_width: true,
    image_advtab: true,
    autoresize_bottom_margin: 20
  },
 
};
