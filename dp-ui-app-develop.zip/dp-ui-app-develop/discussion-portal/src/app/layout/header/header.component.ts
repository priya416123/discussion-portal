import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from 'keycloak-angular';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  username;
  constructor(
    private router:Router,
    private keycloakService:KeycloakService
  ) { }

  ngOnInit() {

    this.keycloakService.isLoggedIn()
    .then((status:boolean)=>{
      this.username = this.keycloakService.getUsername()
    })
    .catch(error => console.log("Something went Wrong..."))
  }

  logout(){
    this.keycloakService.logout();
  }


  onPost(){
    this.router.navigate(["question"]);
  }
}
