import { Component, OnInit, OnDestroy, Input } from "@angular/core";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from "@angular/forms";
import { Subscription } from "rxjs";
import { debounceTime } from "rxjs/operators";
import { PingPongService } from "src/app/ping-pong.service";
import { MessageService } from "src/app/message.service";

@Component({
  selector: "app-stitch-btn",
  templateUrl: "./stitch-btn.component.html",
  styleUrls: ["./stitch-btn.component.css"]
})
export class StitchBtnComponent implements OnInit, OnDestroy {
  @Input() response: any;
  @Input() question: any;

  stitchForm: FormGroup;
  books;
  chapters;
  results;
  subscriptions: Subscription[] = [];
  toggleButton: boolean = false;
  constructor(
    private fb: FormBuilder,
    private pingService: PingPongService,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    let subs = this.pingService.getBooks().subscribe((res: any) => {
      this.books = res;
      console.log("books:", this.books);
    });
    this.subscriptions.push(subs);
    this.stitchForm = this.fb.group({
      book_title: new FormControl("", Validators.required),
      chapter_name: new FormControl("")
    });

    let sub1 = this.stitchForm
      .get("book_title")
      .valueChanges.pipe(debounceTime(200))
      .subscribe(result => {
        this.results = this.books.filter(
          d =>
            result.toLowerCase() != d.bookName &&
            result.length > 0 &&
            d.bookName.toLowerCase().includes(result.toLowerCase())
        );
      });
    this.subscriptions.push(sub1);
  }

  onStitchButtonClick() {
    this.toggleButton = !this.toggleButton;
  }

  onUpdate() {}

  onSubmit(e: any) {
    let payload = {};
    let booktitle;
    let chapterName;
    let chapters;

    if (this.books.map(e => e.bookName).includes(e.value.book_title)) {
      let book = this.books.filter(function(item) {
        return item.bookName == e.value.book_title;
      })[0];
      if (
        book.chapters.map(e => e.chapterName).includes(e.value.chapter_name)
      ) {
        booktitle = e.value.book_title;
        chapterName = e.value.chapter_name;
        let chapterInstance = book.chapters.filter(function(item) {
          return item.chapterName == e.value.chapter_name;
        })[0];
        let notes = [{
          title: this.question,
          contentType: "text/markdown",
          content: this.response.response,
          ref: "TBD"
        }];
        this.pingService
          .createNotes(book.bookId, chapterInstance.chapterId, notes)
          .subscribe(res => {});
      } else {
        let chapter = {
          chapterName: e.value.chapter_name,
          notes: [
            {
              title: this.question,
              content: this.response.response,
              ref: "TBD"
            }
          ]
        };
        this.pingService.createChapter(book.bookId, chapter).subscribe(res => {
          console.log("res:", res);
        });
      }
      this.pingService.pongEvent.emit(this.response.response);
      this.messageService.showMessage("the book has been added successfully");
    } else {
      payload = {
        bookName: e.value.book_title,
        description: "",
        chapters: [
          {
            chapterName: e.value.chapter_name,
            notes: [
              { title: this.question, content: this.response.response, ref: "" }
            ]
          }
        ]
      };

      this.pingService.addBook(payload).subscribe(res => {});
      this.pingService.pongEvent.emit(this.response.response);
      this.messageService.showMessage("the book has been added successfully");
    }
  }

  onBookSelect(e: any) {
    this.stitchForm.patchValue({
      book_title: e.bookName
    });

    this.chapters = e.chapters;
    setTimeout(() => {
      this.results = [];
    }, 500);
  }

  onChapterSelect(e: any) {
    this.stitchForm.patchValue({
      chapter_name: e.chapterName
    });
    setTimeout(() => {
      this.chapters = [];
    }, 500);
  }

  ngOnDestroy() {
    this.subscriptions.forEach((sub: Subscription) => {
      sub.unsubscribe();
    });
  }
}
