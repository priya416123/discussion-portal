import { Component, OnInit, OnDestroy } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Subscription } from "rxjs";
import { DB } from "src/app/db.options";
import { MatBottomSheet } from "@angular/material";
import { ReplyComponent } from "../reply/reply.component";
import { PingPongService } from "src/app/ping-pong.service";

@Component({
  selector: "app-post-details",
  templateUrl: "./post-details.component.html",
  styleUrls: ["./post-details.component.css"],
})
export class PostDetailsComponent implements OnInit, OnDestroy {
  subscriptions: Subscription[] = [];
  dataSource;
  dbData = DB;
  isLoading = true;
  sysdate;
  seq = 0;
  titleId;
  currentResponse;
  togglebutton: boolean = true;
  userName;
  constructor(
    private route: ActivatedRoute,
    private pongService: PingPongService,
    private _bottomSheet: MatBottomSheet
  ) {}

  openBottomSheet(): void {
    let bottomSheet = this._bottomSheet.open(ReplyComponent, {
      panelClass: "my-component-bottom-sheet",
      data: { dataSource: this.dataSource },
    });

    bottomSheet.afterDismissed().subscribe((dataFromChild) => {
      console.log(dataFromChild);
      if (dataFromChild) {
        this.pongService.updateTopic(this.titleId, dataFromChild);
        setTimeout(() => {
          this.loadDataSource();
        }, 500);
      }
    });
  }

  showStitch(response) {
    this.currentResponse = response;
    this.togglebutton = !this.togglebutton;
  }

  loadDataSource() {
    this.isLoading = true;
    let titleSub = this.route.paramMap.subscribe((params) => {
      this.titleId = params.get("id");
      let pongSub = this.pongService
        .getTopic(this.titleId)
        .subscribe((response: any) => {
          this.dataSource = response;
          this.parameterInitialize();
          this.isLoading = false;
        });
      this.subscriptions.push(pongSub);
    });
    this.subscriptions.push(titleSub);
  }

  parameterInitialize() {
    this.sysdate = this.pongService.getSysdate();
  }

  ngOnInit() {
    this.userName = this.pongService.getUser();
    this.pongService.pongEvent.subscribe((res) => {
      this.showStitch(res.value);
    });

    this.loadDataSource();
  }

  ngOnDestroy() {
    this.subscriptions.forEach((sub) => {
      sub.unsubscribe();
    });
  }
}
