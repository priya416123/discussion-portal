import { Component, OnInit, Inject } from "@angular/core";
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from "@angular/material";
import { CONFIG } from "src/app/tineMce-config";
import { environment } from "src/environments/environment";
import { PingPongService } from "src/app/ping-pong.service";

@Component({
  selector: "app-reply",
  templateUrl: "./reply.component.html",
  styleUrls: ["./reply.component.css"]
})
export class ReplyComponent implements OnInit {
  config = CONFIG;
  apiKey = environment.apiKey;
  responseData;

  constructor(
    private _bottomSheetRef: MatBottomSheetRef<ReplyComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private pongService: PingPongService
  ) {}

  openLink(event: MouseEvent): void {
    this._bottomSheetRef.dismiss();
    event.preventDefault();
  }

  onReset() {
    this.responseData = null;
  }

  ngOnInit() {}

  onSubmit() {
    console.log("responseData:", this.responseData);
    let payload = {
      responseId: Math.random().toString(),
      response: this.responseData,
      userId: this.pongService.getUser()
    };
    this._bottomSheetRef.dismiss(payload);
  }
}
