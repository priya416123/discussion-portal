import { Component, OnInit, OnDestroy } from "@angular/core";
import { DB, CATEGORIES } from "src/app/db.options";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";
import { PingPongService } from "src/app/ping-pong.service";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit, OnDestroy {
  dataSource = [];
  categories = CATEGORIES;
  category;
  dataSet = [];
  subscriptions: Subscription[] = [];
  isLoading: boolean = true;
  searchText;
  constructor(private pongService: PingPongService, private router: Router) {}

  ngOnInit() {
    this.isLoading = true;
    let pongSub = this.pongService.getTopics().subscribe((res: any) => {
      this.dataSource = res;
      this.dataSet = this.dataSource;
      this.isLoading = false;
    });
    this.subscriptions.push(pongSub);
  }

  onCategoryFilter(value) {
    if (value != "All Categories") {
      this.dataSource = this.dataSet.filter(function(item) {
        return item.category == value;
      });
    } else {
      this.dataSource = this.dataSet;
    }
  }

  toTopic(data) {
    this.router.navigate(["details", `${data.topicId}`]);
  }

  newTopic() {
    this.router.navigate(["question"]);
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => {
      sub.unsubscribe();
    });
  }
}
