import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, FormControl } from "@angular/forms";
import { CONFIG } from "src/app/tineMce-config";
import { environment } from "src/environments/environment";

import { CATEGORIES } from "src/app/db.options";
import { PingPongService } from "src/app/ping-pong.service";
import { MessageService } from "src/app/message.service";

@Component({
  selector: "app-post-question",
  templateUrl: "./post-question.component.html",
  styleUrls: ["./post-question.component.css"]
})
export class PostQuestionComponent implements OnInit {
  questionForm: FormGroup;
  view;
  config = CONFIG;
  apiKey = environment.apiKey;
  questionList = [
    "Include details about your goal",
    "Describe expected and actual results",
    "Include any error messages"
  ];
  categories = CATEGORIES;
  questionType = ["Public", "Anonymous"];
  que_type;

  constructor(
    private formBuilder: FormBuilder,
    private pongService: PingPongService,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    this.questionForm = this.formBuilder.group({
      topic: new FormControl(),
      type: new FormControl(),
      category: new FormControl(),
      tag: new FormControl(null),
      question: new FormControl()
    });
  }

  reset() {
    this.questionForm.reset();
  }
  onSubmit(payload) {
    payload.userId = this.pongService.getUser();
    payload.responses = [];
    // this.pongService.setDB(payload);
    this.pongService.addTopic(payload).subscribe((res: any) => {});
    this.messageService.showMessage("topic added successfuly");
  }
}
