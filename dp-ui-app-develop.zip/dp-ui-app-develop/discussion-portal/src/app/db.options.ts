export const DB = [
    {
        userId: "User1",
        category:"Business",
        topic:" crucial to the success of a startup??",
        question:"<div><div>Which is more crucial to the success of a startup: the idea or the execution?</div></div>",
        responses : [
            {responseId:1, response: "<div><div>it's about situation and mindset of excution that matter.. No one ever achived any sucess without facing problems or seing opirtunity that other rejected ..so try hard on excution of idea to reality ...</div></div>", responses:[] ,userId: "user2"},

        ]
    },
    {
        userId: "User1",
        category:"Sports",
        topic:" Best Sport in the World",
        question:"<div><div>Which is the best sport in the world and why?</div></div>",
        responses : [
           
            {responseId:1, response: "<div><div>Football reaches billions around the world, and only one or two other sports can claim that. Football can be played nearly anywhere as well. It is overwhelmingly the most played sport among those in developing nations for that reason. No other sports can say that 1 billion+ watched their World Cup final.</div></div>", responses:[] ,userId: "user1"}
        ]
    },
    {
        userId: "User1",
        category:"Business",
        topic:" HR Hiring??",
        question:"<div><div>How do you avoid hiring the wrong people for your startup?</div></div>",
        responses : [
            {responseId:"res1", response: "<div><div>1. Make them show, not tell , 2. Be painfully thorough , 3.. Be consistent , 4.Resist optimism</div></div>", responses:[] ,userId: "user1"}
        

        ]
    },
    {
        userId: "User1",
        category:"Sports",
        topic:" tennis",
        question:"<div><div>why in tennis do they start the game with 'love all'?</div></div>",
        responses : [
            {responseId:"res1", response: "<div><div>LOVE indicates the point 'zero' in tennis. Since both players start off their game with zero point, it is called ''LOVE all'. ... The origin of the use of 'love' for zero is also disputed. It is possible that it derives from the French expression for 'the egg' (l'œuf) because an egg looks like the number zero.</div></div>", responses:[] ,userId: "user1"}

        ]
    }
]

export const CATEGORIES = [
    "All Categories","Business","Sports","Technology","Politics","Travel","Fashion","Movies"

]

