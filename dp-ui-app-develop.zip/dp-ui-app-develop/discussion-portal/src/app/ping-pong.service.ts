import { Injectable, EventEmitter } from '@angular/core';
import { DB } from './db.options';
import * as moment from "moment";
import "moment/locale/pt-br";
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { KeycloakService } from 'keycloak-angular';


@Injectable({
  providedIn: 'root'
})
export class PingPongService {
  db:any[] = DB;
  data;
  pongEvent = new EventEmitter<any>();
  user = "User1";
  constructor(
    private http:HttpClient,
    private keycloakService:KeycloakService
  ) { }

  getDB(){
   return  this.db;
  }

  setDB(payload){
    this.db.push(payload);
  }

  getUser(){

    // Need to include the current user id once key cloak is configured
    return this.keycloakService.getUsername();
  }

  setTopicData(data){
    this.data = data;
  }
  
  getTopicData(){
    return this.data;
  }

  getSysdate(){
     return moment(new Date()).format();
  }

  getTopics(){
    return this.http.get(`${environment.apiUrl}/topics`);
  }
  getTopic(id){
    return this.http.get(`${environment.apiUrl}/topics/${id}`);
  }

  updateTopic(id,payload){
    this.http.post(`${environment.apiUrl}/topics/${id}/responses`,payload).subscribe(res=>{
      console.log("response:",res);
    })
  }

  addTopic(payload){
   return  this.http.post(`${environment.apiUrl}/topics`,payload);
  }

  getBooks(){
    return this.http.get(`${environment.apiUrl}/books`);
  }

  getBookById(bookId){
    return this.http.get(`${environment.apiUrl}/books/${bookId}`);
  }

  getAllChapters(bookId){
    return this.http.get(`${environment.apiUrl}/books/${bookId}/chapters`);  
   }

   addBook(payload){
    return  this.http.post(`${environment.apiUrl}/books`,payload);
   }

   createChapter(bookId,payload){
    return  this.http.post(`${environment.apiUrl}/books/${bookId}/chapters`,payload);
   }

   createNotes(bookId ,chapterId,payload){
    return  this.http.post(`${environment.apiUrl}/books/${bookId}/chapters/${chapterId}/notes`,payload);
   }

   getChapterById(bookId,chapterId){
    return  this.http.get(`${environment.apiUrl}/books/${bookId}/chapters/${chapterId}`);
   }






   updateBook(id, payload){
    this.http.put(`${environment.apiUrl}/book/${id}`,payload).subscribe(res=>{
      console.log("response:",res);
    })
   }

  

}
