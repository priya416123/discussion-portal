# Discussion Portal with Stitch Book

Discussion Portal is ubiqutous and has become commodity.  Due to Covid situation, there is a surge in usage of collobaration tools.  Schools, Universities and Academy have started having their regular classes and discussions online.

Over the years, we have done searching for solutions, posting questions for the unknowns, saving bookmarks of the blogs or forum responses we like - sometimes over note making tools, sometimes put it on Git repos etc.,

We prefer to provide a seamless experience to the new takers.  One giveaway from my team would be "Stitch Book" - an adaptive tool which can be used to push the notes from "Discussion Portal" (for now) to create "Books and Chapters".  Users should be able to make the book public or private depends on their generosity or sensitivity of the content.

IT folks can use the same feature to create Run Book or Cook Book and publish

# Features 

Barebone features for the discussion portal and stitch book are provided below,

## Discussion Portal

	a. Content feature ==> WYSIWYG along with support for equations/forumlas
	b. Create "Topic" ==> Original Question / Context along with associated category
	c. Replies "Response (recursive)" ==> [Content]
	d. Only button would be stitch
	e. Basic Search ==> By "Category"

## Stitch Book
	a. Create a "Book"
	b. Create a "Chapter"
	c. Create a "Note" (Paragraph)
	d. Browse all Books

# Keycloak Setup

1. Install Keycloak - All defaults
2. Import realm - keycloak-realm.json
3. Create couple of users and set the password

# Servers to start

1. Start the API mock server - api-mock-server - npm start
	http://localhost:3000/api

2. Start the Stitch Book web server - stitch-book - npm start
	http://localhost:4202

3. Start the Discussion Portal web server - discussion-portal - npm start
	http://localhost:4200

# Angular Microfrontend

![Angular Microfrontend](hackathon.png)





