const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');


app.use(cors())
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

var mongo = require('mongodb');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";


app.get('/topic',(req,res)=>{
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("pingpong");
        dbo.collection("topics").find({}).toArray(function(err, result) {
          if (err) throw err;
          res.send(result);
          db.close();
        });
      });
})

app.get('/topic/:topicid',(req,res)=>{
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("pingpong");
        var query = {"_id": mongo.ObjectID(req.params.topicid)};
        dbo.collection("topics").find(query).toArray(function(err, result) {
          if (err) throw err;
          res.send(result);
          db.close();
        });
      });
})

app.put('/topic/:topicid',(req,response)=>{
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("pingpong");
        var myquery = {"_id": mongo.ObjectID(req.params.topicid)};
        var newvalues = { $set: req.body };
        dbo.collection("topics").updateOne(myquery, newvalues, function(err, res) {
          if (err) throw err;
          response.send("1 document updated");
          db.close();
        });
      });
})


app.post('/topic',(req,response)=>{
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("pingpong");
        dbo.collection("topics").insertOne(req.body, function(err, res) {
          if (err) throw err;
          response.send("Document Inserted")
          db.close();
        });
      });
})

app.post('/book',(req,response)=>{
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("pingpong");
        dbo.collection("books").insertOne(req.body, function(err, res) {
          if (err) throw err;
          response.send("Document Inserted")
          db.close();
        });
      });
})

app.get('/book',(req,res)=>{
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("pingpong");
        dbo.collection("books").find({}).toArray(function(err, result) {
          if (err) throw err;
          res.send(result);
          db.close();
        });
      });
})

app.get('/book/:bookid',(req,res)=>{
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("pingpong");
        var query = {"_id": mongo.ObjectID(req.params.bookid)};
        dbo.collection("books").find(query).toArray(function(err, result) {
          if (err) throw err;
          res.send(result);
          db.close();
        });
      });
})

app.put('/book/:bookid',(req,response)=>{
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("pingpong");
        var myquery = {"_id": mongo.ObjectID(req.params.bookid)};
        var newvalues = { $set: req.body };
        dbo.collection("books").updateOne(myquery, newvalues, function(err, res) {
          if (err) throw err;
          response.send("1 document updated");
          db.close();
        });
      });
})

app.listen(8083,()=>{console.log("Listening at port 8083")});